/**
 * Server-side Brickken API client.
 * Keys are read from environment variables and never sent to the browser.
 * This file must only be imported from server code (API routes, server
 * components, server actions), never from client components.
 */

const BASE_URL = process.env.BRICKKEN_API_BASE_URL ?? "";
const API_KEY = process.env.BRICKKEN_API_KEY ?? "";

type BrickkenRequestOptions = {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  path: string;
};

export class BrickkenApiError extends Error {
  status: number;
  details: unknown;

  constructor(message: string, status: number, details: unknown) {
    super(message);
    this.name = "BrickkenApiError";
    this.status = status;
    this.details = details;
  }
}

/**
 * Low-level request helper. All Brickken feature functions in this file
 * (and future files) should call this instead of using fetch directly,
 * so auth, error handling, and logging stay consistent.
 */
async function brickkenRequest<TResponse>({
  method = "GET",
  body,
  path,
}: BrickkenRequestOptions): Promise<TResponse> {
  if (!BASE_URL || !API_KEY) {
    throw new BrickkenApiError(
      "Brickken API is not configured. Set BRICKKEN_API_BASE_URL and BRICKKEN_API_KEY.",
      500,
      null
    );
  }

  const response = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`,
    },
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
  });

  const contentType = response.headers.get("content-type") ?? "";
  const payload = contentType.includes("application/json")
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    throw new BrickkenApiError(
      `Brickken request failed: ${method} ${path}`,
      response.status,
      payload
    );
  }

  return payload as TResponse;
}

/**
 * Placeholder feature functions. Each one maps to a stage of the RWAOS
 * lifecycle from the spec. Implementations will be filled in against the
 * actual Brickken API contract as endpoints are confirmed.
 */
export const brickken = {
  createTokenizationRequest: (payload: unknown) =>
    brickkenRequest({ path: "/tokenization", method: "POST", body: payload }),

  createSto: (payload: unknown) =>
    brickkenRequest({ path: "/sto", method: "POST", body: payload }),

  getInvestorStatus: (investorId: string) =>
    brickkenRequest({ path: `/investors/${investorId}` }),

  whitelistInvestor: (payload: unknown) =>
    brickkenRequest({ path: "/whitelist", method: "POST", body: payload }),

  invest: (payload: unknown) =>
    brickkenRequest({ path: "/investments", method: "POST", body: payload }),

  claimTokens: (payload: unknown) =>
    brickkenRequest({ path: "/claims", method: "POST", body: payload }),

  mint: (payload: unknown) =>
    brickkenRequest({ path: "/mint", method: "POST", body: payload }),

  burn: (payload: unknown) =>
    brickkenRequest({ path: "/burn", method: "POST", body: payload }),

  transfer: (payload: unknown) =>
    brickkenRequest({ path: "/transfer", method: "POST", body: payload }),

  distribute: (payload: unknown) =>
    brickkenRequest({ path: "/distributions", method: "POST", body: payload }),

  closeSto: (stoId: string) =>
    brickkenRequest({ path: `/sto/${stoId}/close`, method: "POST" }),

  getTransactionStatus: (txId: string) =>
    brickkenRequest({ path: `/transactions/${txId}` }),
};
